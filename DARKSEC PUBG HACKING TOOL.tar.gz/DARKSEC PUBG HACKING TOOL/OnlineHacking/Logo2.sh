
echo -e "\e[1;96m< < < ============================================================ > > >\e[m "
printf " \e[1;31m\e[0m\e[1;92m\e[0m\e[1;31m \e[0m\e[1;37;44m\e[0m " 
echo " "
printf "\e[1;31m[\e[0m\e[1;92m01\e[0m\e[1;31m] \e[0m\e[1;37;44m X Suit \e[0m                 \e[1;31m[\e[0m\e[1;92m06\e[0m\e[1;31m] \e[0m\e[1;91;107m BGMI 4 Anniversarry \e[0m  \e[95m[\e[93mNew\e[95m[\e[0m "
echo
printf "\e[1;31m\e[0m\e[1;92m\e[0m\e[1;31m \e[0m\e[1;37;44m\e[0m"     
echo
printf "\e[1;31m[\e[0m\e[1;92m02\e[0m\e[1;31m] \e[0m\e[1;37;41m Avalanche X-Suit \e[0m       \e[1;31m[\e[0m\e[1;92m07\e[0m\e[1;31m] \e[0m\e[1;34;103m PUBG 4 Anniversarry \e[0m  \e[95m[\e[93mNew\e[95m[\e[0m "
echo
printf "\e[1;31m\e[0m\e[1;92m\e[0m\e[1;31m \e[0m\e[1;37;44m\e[0m"
echo
printf "\e[1;31m[\e[0m\e[1;92m03\e[0m\e[1;31m] \e[0m\e[1;91;107m MidasBuy \e[0m               \e[1;31m[\e[0m\e[1;92m08\e[0m\e[1;31m] \e[0m\e[1;37;41m PUBG RP-M9 \e[0m  \e[95m[\e[93mNew\e[95m[\e[0m "
echo
printf "\e[1;31m\e[0m\e[1;92m\e[0m\e[1;31m \e[0m\e[1;37;44m\e[0m"
echo
printf "\e[1;31m[\e[0m\e[1;92m04\e[0m\e[1;31m] \e[0m\e[1;34;103m SPIN EVENT \e[0m             \e[1;31m[\e[0m\e[1;92m09\e[0m\e[1;31m] \e[0m\e[1;91;102m BGMI Collect M416 \e[0m  \e[95m[\e[93mNew\e[95m[\e[0m"
echo
printf "\e[1;31m\e[0m\e[1;92m\e[0m\e[1;31m \e[0m\e[1;37;44m\e[0m"
echo
printf "\e[1;31m[\e[0m\e[1;92m05\e[0m\e[1;31m] \e[0m\e[1;48;5;21m Collect Car Event \e[0m      \e[1;31m[\e[0m\e[1;92m10\e[0m\e[1;31m] \e[0m\e[1;48;5;200m BGMI Car Event \e[0m  \e[95m[\e[93mNew\e[95m[\e[0m"
echo
printf "\e[1;31m\e[0m\e[1;92m\e[0m\e[1;31m \e[0m\e[1;37;44m\e[0m"   
echo
printf "\e[1;31m[\e[0m\e[1;92m99\e[0m\e[1;31m] \e[0m\e[1;33mExit\e[0m                     \e[1;31m[\e[0m\e[1;92m50\e[0m\e[1;31m] \e[0m\e[1;33mAbout\e[0m\n"
echo " "
echo -e "\e[1;96m< < < ============================================================ > > >\e[m "
echo ""
