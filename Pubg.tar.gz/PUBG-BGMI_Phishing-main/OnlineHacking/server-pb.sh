         echo""
         echo ""
         echo -e $" \e[91m[\e[92m★\e[91m]\e[1;93m Online Hacking Server Connect... \e[0m  "
			   sleep 2
			   echo ""
			   echo -e $" \e[91m[\e[92m★\e[91m]\e[1;93m Server Status Chacking ... \e[0m  "
			   sleep 2
			   echo ""
			   echo -e $" \e[91m[\e[1;92m★\e[1;91m]\e[1;93m Turn On Mobile Hostpot ... \e[0m   "
			   sleep 4
			   echo ""
			   echo -e $" \e[91m[\e[92m★\e[91m]\e[1;96m PHP Server Now Startng ... \e[0m  "
                           echo ""
			   php -S 127.0.0.1:4444 > /dev/null 2>&1 &
                           sleep 3
			   echo -e $" \e[91m[\e[92m-\e[91m]\e[1;95m Start LocalHost... :  \e[0m http://127.0.0.1:4444 "
			   echo ""
			   sleep 2
			   echo -e $" \e[91m[\e[0m-\e[91m]\e[1;92m Launching Ngrok... : \e[0m Turn On Mobile Hostpot  "
			   echo ""
			   sleep 5
